function [I,Rout] = Infil_runoff(S,P,LAI,soil_par,Zr)
    % INFILTRATION
    % we assume that the daily infiltration rate is a constant
    % S: average soil moisture content in the profile
    % P: daily precipitation
    % Rin: input runoff
    % LAI: leaf area index of per unit
    % Zr : active root depth, mm
 % ------------------------------------------------------------------
   %% daily infiltration rate
    Icbare = soil_par(11);    %12;            % daily infiltration capacity of bare soil, mm/h
    Icveg = soil_par(12);     %36;             % daily infiltration capacity of vegetation, mm/h
    % total vegetation cover fraction
    Vt = 1 - exp(-0.75*LAI);
    % infiltration rate
    Ia = Icveg*Vt+Icbare*(1-Vt);
   %% soil parameters
    n = soil_par(5);    % soil porosity
    %% the amount of rainfall reaching the soil
    index= find(P<0);
    P(index) = 0;
    pre = P;
    clear A2 index

    I = minimumF(pre,Ia,n*Zr*(1-S));
    Rout = pre-I;
    index = find(Rout <0);
    Rout(index) = 0;
    clear index
    %% runoff redistribution
    for i = 3:34
        [Rout(:,:,i-1,2),I(:,:,i,2)] = runoff(Rout(:,:,i-1,2),Ia(:,:,i,2),S(:,:,i,2),I(:,:,i,2),n,Zr);
        Rout(:,:,i,2) = Rout(:,:,i-1,2)+Rout(:,:,i,2);
    end
end
    
    
%% runoff
function [Qin,I] = runoff(Qin,Ia,S,I,n,Zr)
    [~,~,a,b] = size(S);
    for i = 1:a
        for j = 1:b
            S(:,:,i,j) = S(:,:,i,j)+I(:,:,i,j)/(n*Zr);
            newIn = minimum(Qin(:,:,i,j),Ia(:,:,i,j)-I(:,:,i,j),n*Zr*(1-S(:,:,i,j)));
            I(:,:,i,j) = I(:,:,i,j)+newIn;
            Qin(:,:,i,j) = max(Qin(:,:,i,j)-newIn,0);
        end
    end
end
%% find the minimum number
function [mini] = minimum(a,b,c)
    if a<b
        mini=a;
    else
        mini=b;
    end
    if mini>c
        mini = c;
    end
end
%
function [a] = minimumF(a,b,c)
    A = a-b;
    index = find(A>0);
    a(index) = b(index);
    
    B = a -c;
    index = find(B>0);
    a(index) = c(index);
end
                
    
    
    

