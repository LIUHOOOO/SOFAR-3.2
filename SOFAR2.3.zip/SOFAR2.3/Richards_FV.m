function [Q] = Richards_FV(K,lambda,dz)
%RICHARDS2D_FV �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    % a well   
%     Theta = Theta_e(1:70,1:10,:);        % center
% %     Theta_a = Theta_e(1:70,11:20,:);      % a
%     Theta_b = Theta_e(1:70,11:20,:);      % b
% %     Theta_c = Theta_e(1:70,31:40,:);      % c
%     Theta_d = Theta_e(1:70,21:30,:);      % d
%     Theta_E = Theta_e(1:70,51:60,:);      % e
%     Theta_f = Theta_e(1:70,61:70,:);      % f
    
%     Da = D(1:70,11:20,:);
%     Dc = D(1:70,21:30,:);
%     Db = D(1:70,31:40,:);
%     Dd = D(1:70,41:50,:);
%     De = D(1:70,51:60,:);
%     Df = D(1:70,61:70,:);
    a = 165;
    Kb = K(:,a+1:2*a,:,:,:);    % K(2) = Km, k+1/2
%     Kb(:,:,1) = 0;
    Kd = K(:,2*a+1:3*a,:,:);    % K(3) = Kp, k-1/2
    
%     qa = lambda*Da.*(Theta_a-Theta);
%     qc = lambda*Dc.*(Theta_c-Theta);
%     qb = lambda*Db.*(Theta_b-Theta);
%     qd = lambda*Dd.*(Theta_d-Theta)+dz*lambda*(-Kd+Kb);
%     qe = lambda*De.*(Theta_E-Theta);
%     qf = lambda*Df.*(Theta_f-Theta);
    
    
    Q = dz*lambda*(-Kd+Kb);
end

