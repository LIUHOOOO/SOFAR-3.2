function [I,Routput,dem] = Runoff_F(Rinput,I,n,Zr,Ia,S,DEMinput,Biomass,Index,Vt,rain)
%% input variables:
% (1)Rinput: initial runoff, defined as precipitation minus infiltration;
% (2)DEMinput: DEM
% (3)Biomass: biomass of per grid;
% (4)Index: location of photovoltaic panels
% (5)Vt: input vegetation coverage
% (6)I: initial infiltration
% (7)Ia: potential infiltration,i.e., infiltration capacity
% (8)n: soil porosity
% (9)Zr: root depth
    %% fill sink and zero slope area
%     [DEMi] = DEMfillsink(DEMinput);
    Rout = Rinput;
    [a,b] = size(Rout);
    dem = ones(a,b);
    dem(2:a-1,2:b-1) = DEMinput;
    dem(1,1:b) = dem(2,1:b)-5;
    dem(1:a,1) = dem(1:a,2)-5;
    dem(a,1:b) = dem(a-1,1:b)-5;
    dem(1:a,b) = dem(1:a,b-1)-5;
    DEM = dem;    % size: a,b 
%     DEMout = DEM(2:a-1,2:b-1);
    %% save output runoff
    Routput = 0;
    S(2:a-1,2:b-1) = S(2:a-1,2:b-1)+I(2:a-1,2:b-1)./(n*Zr); % refresh soil moisture content

    while sum(sum(Rout(2:a-1,2:b-1))) ~= 0
        Routold = Rout;         % save original runoff input matrix
%% D8, sort order from left to right, from up to bottom
        % 1,2,3,4,5,6,7,8
        % point 1
        distance = 3;
        slope1 = meanSlope(DEM(2:a-1,2:b-1),DEM(2:a-1,1:b-2),distance);
        clear distance
        % point 2
        distance = 3*power(2,0.5);
        slope2 = meanSlope(DEM(2:a-1,2:b-1),DEM(1:a-2,1:b-2),distance);
        clear distance
        % point 3
        distance = 3;
        slope3 = meanSlope(DEM(2:a-1,2:b-1),DEM(1:a-2,2:b-1),distance);
        clear distance
        % point 4
        distance = 3*power(2,0.5);
        slope4 = meanSlope(DEM(2:a-1,2:b-1),DEM(1:a-2,3:b),distance);
        clear distance
        % point 5
        distance = 3;
        slope5 = meanSlope(DEM(2:a-1,2:b-1),DEM(2:a-1,3:b),distance);
        clear distance
        % point 6
        distance = 3*power(2,0.5);
        slope6 = meanSlope(DEM(2:a-1,2:b-1),DEM(3:a,3:b),distance);
        clear distance
        % point 7
        distance = 3;
        slope7 = meanSlope(DEM(2:a-1,2:b-1),DEM(3:a,2:b-1),distance);
        clear distance
        % point 8
        distance = 3*power(2,0.5);
        slope8 = meanSlope(DEM(2:a-1,2:b-1),DEM(3:a,1:b-2),distance);
        clear distance
        % total slope
        slope = slope1+slope2+slope3+slope4+slope5+slope6+slope7+slope8;
        indexS = find(slope==0);
        slope(indexS) = 0.01;

       %% 
        DEMout = Landscape_evolution(DEM(2:a-1,2:b-1),Routold(2:a-1,2:b-1),slope,Biomass,Index,Vt,rain);
        %%
        R = Routold(2:a-1,2:b-1);
        R(indexS) = 0;
        Routold(2:a-1,2:b-1) = R;
        clear R
        R = Rout(2:a-1,2:b-1);
        R(indexS) = 0;
        Rout(2:a-1,2:b-1) = R;
        clear R index
%         [DEMout] = DEMfillsink(DEMout);
        DEM(2:a-1,2:b-1) = DEMout;
        DEM(1,1:b) = DEM(2,1:b)-1;
        DEM(1:a,1) = DEM(1:a,2)-1;
        DEM(a,1:b) = DEM(a-1,1:b)-1;
        DEM(1:a,b) = DEM(1:a,b-1)-1;
        %% runoff distribution
        Rout(2:a-1,1:b-2) = Rout(2:a-1,1:b-2)+Routold(2:a-1,2:b-1).*(slope1./slope);
        Rout(1:a-2,1:b-2) = Rout(1:a-2,1:b-2)+Routold(2:a-1,2:b-1).*(slope2./slope);
        Rout(1:a-2,2:b-1) = Rout(1:a-2,2:b-1)+Routold(2:a-1,2:b-1).*(slope3./slope);
        Rout(1:a-2,3:b) = Rout(1:a-2,3:b)+Routold(2:a-1,2:b-1).*(slope4./slope);
        Rout(2:a-1,3:b) = Rout(2:a-1,3:b)+Routold(2:a-1,2:b-1).*(slope5./slope);
        Rout(3:a,3:b) = Rout(3:a,3:b)+Routold(2:a-1,2:b-1).*(slope6./slope);
        Rout(3:a,2:b-1) = Rout(3:a,2:b-1)+Routold(2:a-1,2:b-1).*(slope7./slope);
        Rout(3:a,1:b-2) = Rout(3:a,1:b-2)+Routold(2:a-1,2:b-1).*(slope8./slope);
        
        Rout(2:a-1,2:b-1) = Rout(2:a-1,2:b-1) - Routold(2:a-1,2:b-1);
        clear index
        index = find(Rout<0.1);
        Rout(index) = 0;
        clear index
        Routput = sum(Rout(1,:))+sum(Rout(a,:))+sum(Rout(2:a-1,1))+sum(Rout(2:a-1,b))+Routput;

        Rout(1,:) = 0;
        Rout(a,:) = 0;
        Rout(:,1) = 0;
        Rout(:,b) = 0;

        index  = find(Rout<0);
        Rout(index) = 0;
        clear index
        %% re-infiltrating
        newIn = minimum(Rout(2:a-1,2:b-1),Ia(2:a-1,2:b-1)-I(2:a-1,2:b-1),n*Zr*(1-S(2:a-1,2:b-1)));
        I(2:a-1,2:b-1) = I(2:a-1,2:b-1)+newIn;
        middleval = Rout(2:a-1,2:b-1)-newIn;
        index = find(middleval<0);
        middleval(index) = 0;
        Rout(2:a-1,2:b-1) = middleval;
        clear index middleval
        S(2:a-1,2:b-1) = S(2:a-1,2:b-1)+newIn./(n*Zr); % refresh soil moisture content
      
    end
    dem = DEM(2:a-1,2:b-1);    % output new DEM
end


%% find the minimum number
function [mini] = minimum(a,b,c)
    mini = zeros(size(a));
    
    A1 = a-b;
    index = find(A1<0);
    mini(index) = a(index);
    clear index
    index = find(A1>=0);
    mini(index) = b(index);
    clear index
    
    A2 = mini - c;
    index = find(A2>=0);
    mini(index) = c(index);
    clear index
end
% %% runoff
% function [Rout,I,DEMi] = runoff(Rout,Ia,S,I,n,Zr,tr,slope,Index,dem,B)
%     [DEMi] = Landscape_evolution(dem,Rout,slope,B,Index);
%     S = S+I/(n*Zr);
%     newIn = minimum(Rout,Ia-I,n*Zr*(1-S)/tr);
%     I = I+newIn;
%     Rout = max(Rout-newIn,0);
% end
%% slope
function [slope] = meanSlope(DEMi,DEMj,distance)
% input DEM matrix
% DEMi_size: Nx-1,Ny-1;   Center cell
% DEMj_size: Nx-1,Ny-1;   ambient cell
% distance: the distance from center cell to ambient cell
slope = (DEMi - DEMj)/(distance*100);
index = find(slope<0);
slope(index) = 0;
clear index
end





