function [I,Routput,DEMout] = Infil_runoff_F(S,P,LAI,soil_par,Index,I_PV,Rout_PV,DEM,Biomass,rain)
    % INFILTRATION
    % we assume that the daily infiltration rate is a constant
    % S: average soil moisture content in the profile
    % P: daily precipitation
    % Rin: input runoff
    % LAI: leaf area index of per unit
 % ------------------------------------------------------------------
    

%% soil parameters
    n = soil_par(1,5);    % soil porosity
    Zr = 600;     % root depth,mm
    [a,b,~] = size(S);
    I = zeros(a,b);
    Rout = zeros(a,b);
    pre = zeros(a,b);
    Ia = zeros(a,b);
    Vt_input = zeros(a-2,b-2);

%% the areas where can receive rainfall
    for i = 2:a-1
        for j = 2:b-1
            if Index(i-1,j-1) == 0    % no PVs
                Soil_par = soil_par(1,:);
%% daily infiltration rate
                Icbare = Soil_par(11);    %12;            % daily infiltration capacity of bare soil, mm/h
                Icveg = Soil_par(12);     %36;            % daily infiltration capacity of vegetation, mm/h
                % total vegetation cover fraction
                Vt = 1 - exp(-0.75*LAI(i-1,j-1));
                Vt_input(i-1,j-1) = Vt;
                % infiltration rate
                Ia(i,j) = Icveg*Vt+Icbare*(1-Vt);
%% the amount of rainfall reaching the soil
                pre(i,j) = max(P(i,j),0);
                I(i,j) = minimum(pre(i,j),Ia(i,j),n*Zr*(1-S(i,j,2)));
                Rout(i,j) = max(pre(i,j)-I(i,j),0);      % rounoff
            else
                Soil_par = soil_par(2,:);
%% daily infiltration rate
                Icbare = Soil_par(11);    %12;            % daily infiltration capacity of bare soil, mm/h
                Icveg = Soil_par(12);     %36;            % daily infiltration capacity of vegetation, mm/h
                % total vegetation cover fraction
                Vt = 1 - exp(-0.75*LAI(i-1,j-1));
                Vt_input(i-1,j-1) = Vt;
                % infiltration rate               
                Rout(i,j) = Rout_PV(i-1,j-1);
                Ia(i,j) = Icveg*Vt+Icbare*(1-Vt); 
                I(i,j) = I_PV(i-1,j-1);
            end
        end
    end
%% runoff redistribution
    % all rasters, multiplt flow direction method
%     Routput = 0;
    [I,Routput,DEMout] = Runoff_F(Rout,I,n,Zr,Ia,S(:,:,2),DEM,Biomass,Index,Vt_input,rain); 
end
%% find the minimum number
function [mini] = minimum(a,b,c)
    if a<b
        mini=a;
    else
        mini=b;
    end
    
    if mini>c
        mini = c;
    end
end

                
    
    
    

