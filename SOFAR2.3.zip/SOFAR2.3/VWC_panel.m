function [x,Tout,Bout,LAItout,Esout,lgout,Rout,II,TNPP] = VWC_panel(Y,T,...
    PAR,PlantType,xinput,gP,gTmax,gTmin,Ra_PV,Ra_G,Binput,LAIinput,LAIginput,Ipvinput,row,col)
%% initialization and parameter defination
Length = 330;
Depth = 60;
Width = 10;
Z = Depth;      % soil depth, cm;
L = Length;     % x direction simulation range, cm;
Yy = Width;     % y direction simulation range, cm;
dy = 10;
dz = 60;        % cm
dx = 10;        % cm
Zr = 600;       % root depth,mm
dt = 1;         % time step,d;
nz = Z/dz;      % number of soil layer
Nz = nz+2;      % additional layer
nx = L/dx;
Nx = (nx+2);
ny = Yy/dy;
Ny = ny+2;
lambda=dt/dz^2;     % coefficient
Grs = 61;
Grd = 61+210;
Uz = 1.5;
Z = 1110;
Zm = 1.5;
%% parameters defination
soil_par = PAR(1:13);
Veg_PAR = PAR(14:31);

%% soil physical parameter
Sfc = soil_par(4);   % the field capacity,v/v;
n = soil_par(5);    % soil porosity

%% initialization
theta_1 = Sfc/n;      % relative soil moisture content in upboder, v/v;

if Y ==1 && T==1
        x = ones(row,col,Nx,Ny,Nz)*0.1;     % soil moisture matrix,initial soil moisture content,v/v;
        x(:,:,1:14,2:Ny-1,2) = 0.05074/n;   
        % point 4
        x(:,:,15:17,2:Ny-1,2) = 0.1341/n;
        % point 3
         x(:,:,18:31,2:Ny-1,2) = 0.0614/n;
        % point 2
        x(:,:,32:34,2:Ny-1,2) = 0.2158/n;
else
    x = xinput;
end
clear distance i xinput
%% boudary condition
x(:,:,:,:,1) = x(:,:,:,:,2);
x(:,:,:,:,3) = x(:,:,:,:,2);
x(:,:,1,:,:) = x(:,:,2,:,:);
x(:,:,:,1,:) = x(:,:,:,2,:);
x(:,:,:,3,:) = x(:,:,:,2,:);
%%
% define hydraulic condutivity
Ks = soil_par(6);   % hydraulic conductivity parameter, mm/d,saturated;d
N = soil_par(8);            % experience constant
bb = soil_par(9);
%% generated radiation temperature and precipitation
gP = max(gP-2,0);
[AA,BB] = size(gTmax);
Tmaxg = reshape(gTmax',AA*BB,1);
Tming = reshape(gTmin',AA*BB,1);
clear AA BB
%% shape parameter of PVs
length = 2;               % Length of PV panels, m
width = 1;                % Width of PV panels, m
area = 0.3;
S = length*width/(area);    % intercipition coefficient is rate of PVs area and interspace area
Belta = 37.2*pi/180;     % incline angel of PV panels
if PlantType == 1
    Inter_Pre4 = Rain_distribution(gP,Belta,S);
    Inter_Pre2 = Rain_distribution(gP,Belta,S);
elseif PlantType == 2
    Inter_Pre4 = gP;
    Inter_Pre2 = gP;
end
P1 = gP;            % natural precipitation

P7 = gP;
%% main structure
Ra = zeros(row,col,Nx,Ny);
for i= 1:row
    for j = 1:col
        Ra(i,j,:,:) = Ra_PV(i,j);
        Ra(i,j,32:34,:) = Ra_G(i,j);            % Front,there are no PVs
%         Ra(row,col,83:85,:) = Ra_PV;            % there are PVs
        x(i,j,:,:,:) = x(i,j,:,:,:) + Ipvinput(i,j);
    end
end
clear distance i
%% pre-define
B = Binput;
clear Binput
LAIt = LAIinput;
clear LAIinput
LAIg = LAIginput;
clear LAIginput
%% annual loop
        if T < 10 && Y == 1
            Ts10 = mean((-Tming(1:T)+Tmaxg(1:T))/2);
                SWP5i = x(:,:,:,:,2);
        else
            Ts10 = mean((-Tming(T-9+(Y-1)*365:T+(Y-1)*365)+Tmaxg(T-9+(Y-1)*365:T+(Y-1)*365))/2);
%             for dd = T-4:T
                SWP5i = x(:,:,:,:,2);
%             end
        end
        %% main function
        [ET0,Bxp,LAI0,E0,lg0,tNPP0] = VWC(x(:,:,2:Nx-1,2:Ny-1,2),LAIt(:,:,2:Nx-1,2:Ny-1),...
            LAIg(:,:,2:Nx-1,2:Ny-1),soil_par,Veg_PAR,gTmax(Y,T),...
            gTmin(Y,T),Ra(:,:,2:Nx-1,2:Ny-1),B(:,:,2:Nx-1,2:Ny-1,:),...
            Ts10,SWP5i(:,:,2:Nx-1,2:Ny-1),gP(Y,T),T,Grs,Grd,...
            Uz,Z,Zm,PlantType);      % point 7 
        % output datasets
        Tout = zeros(row,col,Nx,Ny);
        Tout(:,:,2:Nx-1,2:Ny-1) = ET0(:,:,1:Nx-2,1:Ny-2);
        Esout = zeros(row,col,Nx,Ny);
        Esout(:,:,2:Nx-1,2:Ny-1) = E0(:,:,1:Nx-2,1:Ny-2);
        LAItout = zeros(row,col,Nx,Ny);
        LAItout(:,:,2:Nx-1,2:Ny-1) = LAI0(:,:,1:Nx-2,1:Ny-2);
        lgout = zeros(row,col,Nx,Ny);
        lgout(:,:,2:Nx-1,2:Ny-1) = lg0(:,:,1:Nx-2,1:Ny-2);
        Bout = zeros(row,col,Nx,Ny,3);
        Bout(:,:,2:Nx-1,2:Ny-1,1) = Bxp(:,:,1:Nx-2,1:Ny-2,1);
        Bout(:,:,2:Nx-1,2:Ny-1,2) = Bxp(:,:,1:Nx-2,1:Ny-2,2);
        Bout(:,:,2:Nx-1,2:Ny-1,3) = Bxp(:,:,1:Nx-2,1:Ny-2,3);
        
        TNPP = zeros(row,col,Nx,Ny);
        TNPP(:,:,2:Nx-1,2:Ny-1) = tNPP0(:,:,1:Nx-2,1:Ny-2);
        

        P = zeros(row,col,Nx,Ny);
        %% precipitation duration
            % P(distance+3:distance+20,2:11) = Inter_Pre2(Y,T)*ones(size(x(distance+3:distance+20,2:11,2)));      % shade
            P(:,:,15:17,2:Ny-1) = Inter_Pre4(Y,T)*ones(size(x(:,:,15:17,2:Ny-1,2)));                   % middle
            % P(distance-17:distance-1,2:11) = Inter_Pre4(Y,T)*ones(size(x(distance-17:distance-1,2)));           % shade
        if PlantType == 2
            P = P7(Y,T)*ones(row,col,Nx,Ny);
        end

        %% ����������
        [I,Rout] = Infil_runoff(x(:,:,:,:,2),P,LAItout,soil_par,Zr);
        I = I/(n*Zr);
        II(:,:,:,:) = I;
        % precipitation,runoff and infiltration
        [x(:,:,2:Nx-1,2:Ny-1,2),I(:,:,2:Nx-1,2:Ny-1)] = pre(x(:,:,2:Nx-1,2:Ny-1,2),I(:,:,2:Nx-1,2:Ny-1));    % soil water redistribution
        %% Evapotranspiration loss
        % root uptake
        [x] = root_uptake(x,Tout(:,:,2:Nx-1,2:Ny-1),soil_par,Zr,P(:,:,2:Nx-1,2:Ny-1));
        x(:,:,2:Nx-1,2:Ny-1,2) = x(:,:,2:Nx-1,2:Ny-1,2)-Esout(:,:,2:Nx-1,2:Ny-1)/(n*Zr);    % first layer minus soil evaporation
        index = x< 0.02/n;
        x(index) = 0.02/n;
        %% boudary condition
        x(:,:,:,:,1) = x(:,:,:,:,2);
        x(:,:,:,:,3) = x(:,:,:,:,2);
        %%
        K = Ks*(x/theta_1).^(N+bb+3);
        r1 = find(x>theta_1);
        K(r1) = Ks;
        %% hydrualic diffusion
        K_p = (K(:,:,2:Nx-1,2:Ny-1,2)+K(:,:,2:Nx-1,2:Ny-1,3))/2;        % vertical,d
        K_m = (K(:,:,2:Nx-1,2:Ny-1,2)+K(:,:,2:Nx-1,2:Ny-1,1))/2;        % vertical,b
        K_t = [K(:,:,2:Nx-1,2:Ny-1,2),K_m,K_p];                         % center,2,3,4,5,6,7
        Theta_t = Richards_FV(K_t,lambda,dz);
        x(:,:,2:Nx-1,2:Ny-1,2) = x(:,:,2:Nx-1,2:Ny-1,2)+Theta_t/n;

end
function [x,Inter_Preout] = pre(X,Inter_Pre)
    SMC = X;
    Inter_Preout = ones(size(Inter_Pre));
    Res = ones(size(SMC)) - SMC;
    SMC = SMC + Inter_Pre;

    A2 = Res - Inter_Pre;
    index = find(A2 >= 0);
    Inter_Preout(index) = 0;
    clear index A2

    A1 = Res - Inter_Pre;
    index = find(A1 < 0);
    SMC(index) = 1;
    Inter_Preout(index) = Inter_Pre(index) - Res(index);
    clear index A1

    x = SMC;
end

function [T_out,B_out,LAIt_out,E_out,Lg_out,tNPP] = VWC(X,LAI,LAIg,soil_par,Veg_PAR,Tmax,...
    Tmin,Solar_radiation,Binput,Ts10,SWP5i,Pre,Date,Grs,Grd,Uz,Z,Zm,PlantType)
VWC = X;
B = Binput;
LAIt = LAI;
Lg = LAIg;


[Ta,Ea] = Evapotranspiraton(VWC,LAIt,Lg,Tmax,...
    Tmin,Solar_radiation,soil_par,Veg_PAR,Uz,Z,Zm,PlantType);

Tmean = (Tmax+Tmin)/2;
[Bp,Lgout,LAItout,tNpp] = vegetation_P(Veg_PAR,soil_par,B,...
    Solar_radiation,Tmean,Pre,Date,Grs,Grd,VWC,...
    SWP5i,Ts10,PlantType);
T_out = Ta;
E_out = Ea;
B_out = Bp;
LAIt_out = LAItout;
Lg_out = Lgout;
tNPP = tNpp;

end

%% root uptake function
function [x] = root_uptake(x,ET,soil_par,Zr,Pdaily)
    [~,~,a,b] = size(ET);
    % ET, daily transpiration, mm/d
    DET = ET/(soil_par(5)*Zr);
    % ET of per layer; 72 X 12 matrix
    % canopy interception minus from transpiration
    P = Pdaily;
    index1 = find(P<=2);
    DET(index1) = DET(index1) - P(index1);
    clear index1
    index2 = find(P>=2);
    DET(index2) = DET(index2) - 2;
    clear index2
    index3 = find(DET<0);
    DET(index3) = 0;
    clear index3
    x(:,:,2:a+1,2:b+1,2) = x(:,:,2:a+1,2:b+1,2)-DET;
end




