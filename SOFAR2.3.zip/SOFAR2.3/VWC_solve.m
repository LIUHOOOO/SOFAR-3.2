function [BOUT,NPP,x,LAI,lg,LAIinputnew,LAIginputnew,...
    Ipvinput,Binputnew,Xinputnew,DEMnew,Routput] = VWC_solve(year,Depth,Length,Width,PAR,File1,File2,Ra_G,Ra_PV,State,...
    x2,LAI2,lg2,B2,LAIinput2,LAIginputnew2,...
    Ipvinput2,Binputnew2,Xinputnew2,DEM2)
%% initialization and parameter defination
Z = Depth;        
L = Length;       % x direction simulation range, cm;
Yy = Width;       % y direction simulation range, cm;
dz = 10;          % cm
nz = Z/dz;        % number of soil layer
Nz = nz+2;        % additional lay
Nx = L+2;
Ny = Yy+2;        % cell size, 12.5m
Date = 365;       % length of growing season
Zr = 600;         % root depth,mm
dt = 1;
lambda=dt/dz^2;   % coefficient
Grs = 61;
Grd = 61+210;
Uz = 1.5;
Z = 1110;
Zm = 1.5;
PlantType = 2;    % shrub
%% parameters defination
soil_par = PAR(:,1:13);
Veg_PAR = PAR(:,14:31);
%% soil physical parameter
% Sh = soil_par(1,1);    % critical soil moisture content,v/v, where soil is very dry;
Sfc = soil_par(1,4);     % the field capacity,v/v;
n = soil_par(1,5);       % soil porosity

% define hydraulic condutivity
Ks = soil_par(1,6);      % hydraulic conductivity parameter, mm/d,saturated;d
N = soil_par(1,8);       % experience constant
bb = soil_par(1,9);
%% generated radiation temperature and precipitation
load(File1);
gP = max(gP-2,0);
[row,col] = size(gP);
Tming = reshape(gTmin',row*col,1);
Tmaxg = reshape(gTmax',row*col,1);

% load Aspect data
Geographic_data = load(File2);                  % 'DEM','Aspect','Slope'
sheetnames_nf = fieldnames(Geographic_data);

name = sheetnames_nf{4};
Index = getfield(Geographic_data,name);         % Digital spatial location of photovoltaic arrays
index = find(Index==1);                         % There are photovoltaic arrays
index(21121:21167) = [];
% divide index into a matrix with size (row,col)
row = 128;
col = 165;
Code  = reshape(index,row,col);

nn = 1;
for i = 1:row
    for j = 1:col
        Xuhao(nn) = find(index == Code(i,j));
        nn  = nn +1;
    end
end
clear nn index
fclose all;
if State == 2
    Index = zeros(size(Index));
elseif State == 1 && year <= 8
    Index = zeros(size(Index));
end
%% time loop
% initialization
theta_1 = Sfc/n;            % relative soil moisture content in upboder, v/v;
if year == 1
    name = sheetnames_nf{2};
    DEMinput = getfield(Geographic_data,name);           % digital surface model
    clear name
    x = ones(Nx,Ny,Nz);     % soil moisture matrix,initial soil moisture content,v/v;
    x = x*0.0827/n;
    LAI = ones(Nx-2,Ny-2)*0.01;
    lg = ones(Nx-2,Ny-2)*0.01;
    B = ones(Nx,Ny,3,(Date+1));
    B(2:Nx-1,2:Ny-1,1,1) = 10*B(2:Nx-1,2:Ny-1,1,1);
    B(2:Nx-1,2:Ny-1,2,1) = 50*B(2:Nx-1,2:Ny-1,2,1);
    B(2:Nx-1,2:Ny-1,3,1) = 2*B(2:Nx-1,2:Ny-1,3,1);
    NPP = zeros(Nx,Ny,(Date+1));
    Routput = zeros(1,Date);
    %%
    Lpv = 35;                                  % length of area under PVs
    Binputnew = zeros(row,col,Lpv,3,3);
    LAIinputnew = ones(row,col,Lpv,3)*0.01;
    LAIginputnew = ones(row,col,Lpv,3)*0.01;
    Binputnew(:,:,:,:,1) = 2;
    Binputnew(:,:,:,:,2) = 5;
    Binputnew(:,:,:,:,3) = 4;
    Xinputnew = ones(row,col,Lpv,3,3)*0.2;     %unse
    if State == 1 && year >= 9
        index = find(Index == 1);
        index(21121:21167) = [];
        Ipvinput = zeros(size(index));
        clear index
    end
else
    B = B2;
    if State == 1 && year == 9
        [ap,bp]= find(Index == 1);
        for i = 1:size(ap,1)
            B(ap(i)+1,bp(i)+1,1,1) = 2;
            B(ap(i)+1,bp(i)+1,2,1) = 5;
            B(ap(i)+1,bp(i)+1,3,1) = 5;
        end
    end
    x = x2;
    LAI = LAI2;
    lg = lg2;
    
    LAIinputnew = LAIinput2;
    LAIginputnew = LAIginputnew2;
    Ipvinput = Ipvinput2;

    Binputnew = Binputnew2;
    Xinputnew = Xinputnew2;
    DEMinput = DEM2;
end
%% Main Loop
fprintf('%s%s%s','This is',num2str(year),'year');
Y = year;
DEMnew = zeros(size(Index,1),size(Index,2),Date);
for day = 1:Date
    disp(day)
    T = day;
    % Farm level
    if T < 10 && Y == 1
        Ts10 = mean((-Tming(1:T)+Tmaxg(1:T))/2);
        SWP5i = x(:,:,2);
    else
        Ts10 = mean((-Tming(T-9+(Y-1)*365:T+(Y-1)*365)+Tmaxg(T-9+(Y-1)*365:T+(Y-1)*365))/2);
        SWP5i = x(:,:,2);
    end
    %% Farm-level
    if State == 2       % Natural cases: there is no PV
        [ET0F,B0F,LAI0F,EF,lg0F,tNPP] = VWC(x(2:Nx-1,2:Ny-1,2),LAI,...,
            lg,soil_par(1,:),Veg_PAR(1,:),gTmax(Y,T),...
            gTmin(Y,T),Ra_G(:,:,T),B(2:Nx-1,2:Ny-1,:,day),Ts10,...
            SWP5i(2:Nx-1,2:Ny-1,:),gP(Y,T),day,Grs,Grd,Uz,Z,Zm,PlantType);
        BxpF = B0F;
    else               % The modeling scenario with PVs
        if Y<= 8       % Pre-construction period
            [ET0F,B0F,LAI0F,EF,lg0F,tNPP] = VWC(x(2:Nx-1,2:Ny-1,2),LAI,...,
                lg,soil_par(1,:),Veg_PAR(1,:),gTmax(Y,T),...
                gTmin(Y,T),Ra_G(:,:,T),B(2:Nx-1,2:Ny-1,:,day),Ts10,...
                SWP5i(2:Nx-1,2:Ny-1,:),gP(Y,T),day,Grs,Grd,Uz,Z,Zm,PlantType);
            BxpF = B0F;
        elseif 8<Y && Y<=10         % Construction period
            [ET0F,B0F,LAI0F,EF,lg0F,tNPP] = VWC(x(2:Nx-1,2:Ny-1,2),LAI,...,
                lg,soil_par(1,:),Veg_PAR(1,:),gTmax(Y,T),...
                gTmin(Y,T),Ra_G(:,:,T),B(2:Nx-1,2:Ny-1,:,day),Ts10,...
                SWP5i(2:Nx-1,2:Ny-1,:),gP(Y,T),day,Grs,Grd,Uz,Z,Zm,PlantType);
            BxpF = B0F;             % Removing vegetation
            LAI0F = zeros(size(LAI0F));
        elseif Y>=11                % Operation period, 40 years
            % Farmlevel
            [ET0F,B0F,LAI0F,EF,lg0F,tNPP] = VWC(x(2:Nx-1,2:Ny-1,2),LAI,...,
                lg,soil_par(1,:),Veg_PAR(1,:),gTmax(Y,T),...
                gTmin(Y,T),Ra_PV(:,:,T),B(2:Nx-1,2:Ny-1,:,day),Ts10,...
                SWP5i(2:Nx-1,2:Ny-1,:),gP(Y,T),day,Grs,Grd,Uz,Z,Zm,PlantType);
            BxpF = B0F;
            % panel level
            [ET0,E,Bxp,LAI0,lg0,Rout_PV,I_PV,xout1,xout2,xout3,TNPP,...
                xinputnew,binputnew,laiinputnew,laiginputnew] = panel_main(Ra_G(:,:,T),Ra_PV(:,:,T),...
                Index,Xinputnew,Binputnew,LAIinputnew,Y,T,PAR(2,:),...
                gP,gTmax,gTmin,LAIginputnew,Ipvinput,Xuhao,row,col);
            Xinputnew = xinputnew;
            clear xinputnew
            Binputnew = binputnew;
            clear binputnew
            LAIinputnew = laiinputnew;
            clear laiinputnew
            LAIginputnew = laiginputnew;
            clear laiginputnew

            %% Integrating
            x(2:Nx-1,2:Ny-1,1) = x(2:Nx-1,2:Ny-1,1).*(1-Index);
            x(2:Nx-1,2:Ny-1,1) = x(2:Nx-1,2:Ny-1,1)+xout1;
            x(2:Nx-1,2:Ny-1,2) = x(2:Nx-1,2:Ny-1,2).*(1-Index);
            x(2:Nx-1,2:Ny-1,2) = x(2:Nx-1,2:Ny-1,2)+xout2;
            x(2:Nx-1,2:Ny-1,3) = x(2:Nx-1,2:Ny-1,3).*(1-Index);
            x(2:Nx-1,2:Ny-1,3) = x(2:Nx-1,2:Ny-1,3)+xout3;
            clear xout1 xout2 xout3
            index = find(Index == 1);     
            ET0F(index) = ET0(index);
            clear ET0
            EF(index) = E(index);
            clear E
            tNPP(index) = TNPP(index);
            clear TNPP
            lg0F(index) = lg0(index);
            clear lg0
            LAI0F(index) = LAI0(index);
            clear LAI0
            % Biomass
            BxpF1 = BxpF(:,:,1);
            Bxp1 = Bxp(:,:,1);
            BxpF1(index) = Bxp1(index);
            clear Bxp1
            
            BxpF2 = BxpF(:,:,2);
            Bxp2 = Bxp(:,:,2);
            BxpF2(index) = Bxp2(index);
            clear Bxp2
            
            BxpF3 = BxpF(:,:,3);
            Bxp3 = Bxp(:,:,3);
            BxpF3(index) = Bxp3(index);
            clear Bxp3 Bxp
            BxpF(:,:,1) = BxpF1;
            BxpF(:,:,2) = BxpF2;
            BxpF(:,:,3) = BxpF3;
            clear BxpF1 BxpF2 BxpF3
        end
    end
    % output datasets
    ET = ET0F(1:Nx-2,1:Ny-2);
    clear ET0F
    Es = EF(1:Nx-2,1:Ny-2);
    clear EF
    NPP(2:Nx-1,2:Ny-1,day+1) = tNPP(1:Nx-2,1:Ny-2);
    clear tNPP
    LAI = LAI0F(1:Nx-2,1:Ny-2);
    clear LAI0F
    lg= lg0F(1:Nx-2,1:Ny-2);
    clear lg0F
    B(2:Nx-1,2:Ny-1,1,day+1) = BxpF(1:Nx-2,1:Ny-2,1);
    B(2:Nx-1,2:Ny-1,2,day+1) = BxpF(1:Nx-2,1:Ny-2,2);
    B(2:Nx-1,2:Ny-1,3,day+1) = BxpF(1:Nx-2,1:Ny-2,3);
    clear BxpF
    %% precipitation processing
    P = gP(Y,T)*ones(Nx,Ny);

    % Infiltration and runoff
    if gP(Y,T)>0
        if State == 2
            I_PV = zeros(Nx-2,Ny-2);
            Rout_PV = zeros(Nx-2,Ny-2);
        elseif Y<=10
            I_PV = zeros(Nx-2,Ny-2);
            Rout_PV = zeros(Nx-2,Ny-2);
        end
        [I,Rout,DEMout] = Infil_runoff_F(x,P,LAI,soil_par,...
            Index,I_PV,Rout_PV,DEMinput,B(2:Nx-1,2:Ny-1,:,day+1),gP(Y,T));
        DEMinput = DEMout;               % refresh DEM
        DEMnew(:,:,day) = DEMinput;
        clear DEMout
        Routput(1,day) = Rout;
        I = I/(n*Zr);
    else
        I = zeros(Nx,Ny);
        DEMnew(:,:,day) = DEMinput;
        Routput(1,day) = 0;
    end

    % precipitation,runoff and infiltration
    [x(2:Nx-1,2:Ny-1,2)] = pre(x(2:Nx-1,2:Ny-1,2),I(2:Nx-1,2:Ny-1));    % soil water redistribution
    if State ==1 && Y>=11
        index = find(Index==1);
        index(21121:21167) = [];
        Iin = I(2:Nx-1,2:Ny-1) - I_PV;
        Ipvinput = Iin(index);       
    else
        Ipvinput = zeros(row,col);
    end
    clear I Iin index
    %% Evapotranspiration loss
    % root uptake
    [x] = root_uptake(x,ET,n,Zr,gP(Y,T));
    x(2:Nx-1,2:Ny-1,2) = x(2:Nx-1,2:Ny-1,2)-Es/(n*Zr);    % first layer minus soil evaporation
    index = x< 0.02/n;
    x(index) = 0.02/n;
    % boudary condition
    x(:,:,1) = x(:,:,2);
    x(:,:,3) = x(:,:,2);
    x(1,:,:) = x(2,:,:);
    x(Nx,:,:) = x(Nx-1,:,:);
    x(:,1,:) = x(:,2,:);
    x(:,Ny,:) = x(:,Ny-1,:);
    %%
    K = Ks*(x/theta_1).^(N+bb+3);
    r1 = x>theta_1;
    K(r1) = Ks;
    %% hydrualic diffusion
    K_p = (K(2:Nx-1,2:Ny-1,2)+K(2:Nx-1,2:Ny-1,3))/2;    % vertical,d
    K_m = (K(2:Nx-1,2:Ny-1,2)+K(2:Nx-1,2:Ny-1,1))/2;    % vertical,b
    K_t = [K(2:Nx-1,2:Ny-1,2),K_m,K_p];                         % center,2,3,4,5,6,7
    Theta_t = Richards3d_FV_F(K_t,lambda,dz,Nx,Ny);
    clear K_t K_m K_p
    x(2:Nx-1,2:Ny-1,2) = x(2:Nx-1,2:Ny-1,2)+Theta_t/n;
    index2 = x < 0.02;
    x(index2)= 0.02;
    index3 = x > 1;
    x(index3)= 1;
    clear Theta_t
%     Xpp(:,:,:,T+1+(Y-1)*365) = x;
    
end
BOUT = B(:,:,:,366);
end

%% FUNCTION
function [x] = pre(X,Inter_Pre)
SMC = X;
Inter_Preout = ones(size(Inter_Pre));
Res = ones(size(SMC)) - SMC;
SMC = SMC + Inter_Pre;

A2 = Res - Inter_Pre;
index = A2 >= 0;
Inter_Preout(index) = 0;
clear index A2

A1 = Res - Inter_Pre;
index = find(A1 < 0);
SMC(index) = 1;
% Inter_Preout(index) = Inter_Pre(index) - Res(index);
clear index A1

x = SMC;
end

function [T_out,B_out,LAIt_out,E_out,Lg_out,tNPP] = VWC(X,LAI,LAIg,soil_par,Veg_PAR,Tmax,...
    Tmin,Solar_radiation,Binput,Ts10,SWP5i,Pre,Date,Grs,Grd,Uz,Z,Zm,PlantType)
VWC = X;
B = Binput;
LAIt = LAI;
Lg = LAIg;

[Ta,Ea] = Evapotranspiraton(VWC,LAIt,Lg,Tmax,...
    Tmin,Solar_radiation,soil_par,Veg_PAR,Uz,Z,Zm,PlantType);

Tmean = (Tmax+Tmin)/2;
[Bp,Lgout,LAItout,tNpp] = vegetation(Veg_PAR,soil_par,B,...
    Solar_radiation,Tmean,Pre,Date,Grs,Grd,VWC,...
    SWP5i,Ts10,PlantType);

T_out = Ta;
E_out = Ea;
B_out = Bp;
LAIt_out = LAItout;
Lg_out = Lgout;
% Q_soil_out = Q_soil;
tNPP = tNpp;

end

%% root uptake function
function [x] = root_uptake(x,ET,n,Zr,Pdaily)
[a,b,~] = size(ET);
% ET, daily transpiration, mm/d
DET = ET./(n*Zr);
% ET of per layer; 72 X 12 matrix
% canopy interception minus from transpiration
P = Pdaily;
index1 = find(P<=2);
DET(index1) = DET(index1) - P(index1);
clear index1
index2 = find(P>=2);
DET(index2) = DET(index2) - 2;
clear index2
index3 = DET<0;
DET(index3) = 0;
clear index3
x(2:a+1,2:b+1,2) = x(2:a+1,2:b+1,2)-DET;
end




