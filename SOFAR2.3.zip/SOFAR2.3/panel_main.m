function [ET0,E,Bxp,LAI0,lg0,Rout_PV,I_PV,x1,x2,x3,TNPP,...
    Xinputnew1,Binputnew1,LAIinputnew1,LAIginputnew1] = panel_main(Ra_G,Ra_PV,...
    Index,Xinputnew,Binputnew,LAIinputnew,Y,T,PAR,gP,...
    gTmax,gTmin,LAIginputnew,Ipvinput,Xuhao,row,col)
%%
    index = find(Index==1);                 % there are photovoltaic arrays
    index(21121:21167) = [];

    Ra_PVin = Ra_PV(index);                 % row: number of PVs; col: 1
    Ra_Gin = Ra_G(index);
    
    %% New method
    Xinput1 = Xinputnew;
    clear Xinputnew
    Binput1 = Binputnew;
    clear Binputnew
    LAIinput1 = LAIinputnew;
    clear LAIinputnew
    LAIginput1 = LAIginputnew;
    clear LAIginputnew;


    disp('PV_panel');
    %% 
    [Nnx,Nny] = size(Index);
    ET0 = zeros(Nnx,Nny);
    E = zeros(Nnx,Nny);                        % soil evaporation
    Bxp = zeros(Nnx,Nny,3);

    LAI0 = zeros(Nnx,Nny);
    lg0 = zeros(Nnx,Nny);
    Rout_PV = zeros(Nnx,Nny);
    I_PV = zeros(Nnx,Nny);
    TNPP = zeros(Nnx,Nny);
    Ipvin = reshape(Ipvinput,row,col);  
    Ra_PVinput = reshape(Ra_PVin,row,col);     % row: number of PVs; col: 1
    Ra_Ginput = reshape(Ra_Gin,row,col);
    %% Main function
        PlantType = 1;
        [soil_moisture,ET0_pv,B0_pv,LAI0_pv,E_pv,lg_pv,Rout_pv,I_pv,TNPP_pv] = VWC_panel(Y,...
            T,PAR,PlantType,Xinput1,gP,gTmax,gTmin,Ra_PVinput,Ra_Ginput,Binput1,LAIinput1,LAIginput1,...
            Ipvin,row,col);

        Xinputnew1 = soil_moisture;
        Binputnew1 = B0_pv;
        LAIinputnew1 = LAI0_pv;
        LAIginputnew1 = lg_pv;
        
        Bxpout1 = zeros(size(Index));
        Bxpout2 = zeros(size(Index));
        Bxpout3 = zeros(size(Index));
       
        
        x1 = zeros(size(Index));
        x2 = zeros(size(Index));
        x3 = zeros(size(Index));
        %%   
        [~,~,c,d] = size(ET0_pv);
        ET0_pv = ET0_pv(:,:,2:c-1,2:d-1);   
        ET0pv = mean(ET0_pv,4);             
        ET0pv = mean(ET0pv,3);              
        ET0pv = reshape(ET0pv,row*col,1);     
        ET0(index(Xuhao)) = ET0pv;         
        clear ET0pv
        
        E_pv = E_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(E_pv,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        E(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        LAI0_pv = LAI0_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(LAI0_pv,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        LAI0(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        lg_pv = lg_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(lg_pv,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        lg0(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        TNPP_pv = TNPP_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(TNPP_pv,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        TNPP(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        I_pv = I_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(I_pv,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        I_PV(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        Rout_pv = Rout_pv(:,:,2:c-1,2:d-1);
        ET0pv = mean(Rout_pv,4);     
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        Rout_PV(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        B1 = B0_pv(:,:,2:c-1,2:d-1,1);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        Bxpout1(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        B1 = B0_pv(:,:,2:c-1,2:d-1,2);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        Bxpout2(index(Xuhao)) = ET0pv;
        clear ET0pv
        
        B1 = B0_pv(:,:,2:c-1,2:d-1,3);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        Bxpout3(index(Xuhao)) = ET0pv;
        clear ET0pv B1
        
        B1 = soil_moisture(:,:,2:c-1,2:d-1,1);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        x1(index(Xuhao)) = ET0pv;
        clear ET0pv
        B1 = soil_moisture(:,:,2:c-1,2:d-1,2);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        x2(index(Xuhao)) = ET0pv;
        clear ET0pv
        B1 = soil_moisture(:,:,2:c-1,2:d-1,3);
        ET0pv = mean(B1,4);
        ET0pv = mean(ET0pv,3);
        ET0pv = reshape(ET0pv,row*col,1);
        x3(index(Xuhao)) = ET0pv;
        clear ET0pv

        Bxp(:,:,1) = Bxpout1;
        Bxp(:,:,2) = Bxpout2;
        Bxp(:,:,3) = Bxpout3;
end

