function [Q] = Richards3d_FV_F(K,lambda,dz,Nx,Ny)
    % a well 
    a = Ny-2;
    Kb = K(1:Nx-2,1+a:Ny-2+a,:);    % K(2) = Km, k+1/2
    Kd = K(1:Nx-2,1+2*a:Ny-2+2*a,:);    % K(3) = Kp, k-1/2
    
    Q = dz*lambda*(-Kd+Kb);
end

