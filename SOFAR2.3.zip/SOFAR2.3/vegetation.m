function [Biomassout,LAIg,LAIt,TNPP] = vegetation(Veg_par,soil_par,Biomass,Ra,Ta,...
    Pre,Date,Grs,Grd,Smean,SWP5i,Ts10,PlantType)
% this function simulate the processes of vegetation growth, senescence,and
% dead caused by physiologic (age) or external factors (fire, cowing,etc).
% -------------------------------------------------------------------------
% Referring to Y. Nouvellon et al., 2000, WRR
% --------------------------------------------------------------------------
% parameter defination:
% (1) ra: canopy boundary layer resistance to water vapour, calculated from PENMAN equation
% (2) rsc: current canopy stomatal resistance to water vapour
% (3) Pre: daily amount of precipitation, mm/d
% (4) Ta: daily average air temperature
% (5) Ra: incident radiation
% (6): the number of day in one year
% (7) Grs: the time for growing season start
% (8) Grd: the time for growing season end
% (9) At0: photosynthetive age at the day before
% (10) Fr: fine root biomass input, ��̬�о���
% (11) Ts10: the average 10 day soil temperature
% (12) SWP5: the average 5 day soil water potential
% (13) Date: the number of day in one year
% (14) S: soil volumetric water content, v/v
% (15) SWP5i: the average 5 day VWC, v/v
% (16) Ts10: the average 10 day air temperature, ��


    % Temperature stress, Tem_S
    Tpmin = Veg_par(1);          % the minimum temperature for vegetation photosynthesis
    Topt = Veg_par(2);           % the optimum temperature for vegetation photosynthesis
%     Tpmax = Veg_par(3);
    if Ta <= Tpmin
        Tem_S = 0;
    elseif Tpmin < Ta && Ta <= Topt
        Tem_S = 1-(Topt-Ta)/(Topt-Tpmin);
    else
        Tem_S = 1;
    end

    % ===============================================================================
    % Water stress reduces photosynthesis by limiting the CO2 diffusion from
    % air to leaf tissues as a result of stomatal closure.
    % Water stress, water_S
%     rsmin = 100;        % minimum canopy stomatal resistence to water vapor, s/m
%     rm = 80;            % mesophyll resistance for water vapor;
%     Water_S=(1.64*rsmin+rm+1.39*rac)/(1.64*rsc+rm+1.39*rac);
%     disp(Water_S)
    Ss = soil_par(3);
    Sw = soil_par(2);
    n = soil_par(5);
    SS = Smean;
    Water_S = zeros(size(SS));
    % part 1
    index = find(SS >= Ss/n);
    Water_S(index) = 1;
    clear index
    % part 2
    index = find(Ss/n>SS & SS>Sw/n);
    Water_S(index) = 1 - power((Ss/n-SS(index))/(Ss/n-Sw/n),4.7);
    clear index
    % part 3
    index = find(SS <= Sw/n);
    Water_S(index) = 0;
    clear index
    %% vegetation parameter
    Bag = Biomass(:,:,1);       % aboveground biomass
    Bs = Biomass(:,:,2);        % structural biomass, including roots and steams
    Bad = Biomass(:,:,3);       % dead biomass
    % ==========================================================================================
    % Eb is described as a function of physiological age
    if PlantType == 1
        Ebmax = 8;               % g DM/MJ
    elseif PlantType == 2
        Ebmax = 15;
    end

    Eb = Ebmax;       % energy conversion efficiency, i.e.,
    % g assimilated CH2O per unit of intercepted PAR
    % calculate photosynthesis, phytosynthesis is only actived during growing season
    % Out of growing season, there no carbohydrote is fixed by plants
    Ec = 0.54;                  % the climatic efficiency (phytosynthetically active radiation, PAR/Ra)
    Sg = Veg_par(4);            % Sg, specific leaf area index for living leaves, g/m2
    Sd = Veg_par(5);            % Sd, specific lear area index for dead leaves, g.m2
    LAIg = Sg*Bag;
    LAIt = LAIg+Sd*Bad;
    if PlantType == 2
        k1 = 0.78;
    elseif PlantType == 1
        k1 = 0.56;
    end
    Ei = exp(-k1*LAIt).*LAIg./LAIt;      % the efficiency of radiation interception bt green leaves
    % =============================================================================================
    % && Biomass allocation &&:  basic assumption: a balance must be maintained between
    % shoots and roots such that the amount of aboveground phytomass that the present
    % root biomass can support is not exceeded
    % ---------------------------------------------------------------------------------------------
    % ----------------------------------------------------------------------------------------------
    % senescence
    da = Veg_par(6);          % biomass senescence rate for aboveground biomass
    Sa = da*(1-Water_S).*Tem_S.*Bag;
    dr = Veg_par(7);          % biomass senescence rate for belowground biomass
    Ssb = dr*Bs;
    % the excess amount of biomass in the shoots:
    rx = Veg_par(18);                  % for pernnial warm season grass
    Bax = max(rx*Bag - Bs, 0);
    Tar = Bax/(1+rx);
    if Date <= Grd && Date >= Grs
        Rasaturation = Veg_par(17);
        val = (Ra >= Rasaturation);
        Ra(val) = Rasaturation;
        Pg = Ra.*Ec.*Ei.*Eb.*Water_S.*Tem_S;

        % allocation coefficient
        ar = ones(size(Tar));
        index = find(Tar<Pg);
        ar(index) = Tar(index)./Pg(index);
        clear index
    else
        Pg = zeros(size(Tar));
        ar = zeros(size(Tar));
    end
    % -----------------------------------------------------------------------------
    % Litter fall
    % littter fall represents standing dead biomass removed from plant through
    % wind, dust, and rainfall
    kr = 0.25*(1-exp(-0.025*Pre));         % pre represents daily amount of rainfall
    kdd = 0.023;
    Tdmax = 10;
    epision = min(Ta/Tdmax,1);
    L = kr.*Bad + kdd*epision*Bad;
    % calculate the C pool of the fine and coarse litters
    if PlantType == 2
        eta = 0.15;
    elseif PlantType == 1
        eta = 1;
    end

    % ==================================================================================
    % root to shoot tanslocation:
    % Translocation of carbohysrates from roots to shoots, Tra occurs during
    % the early growing season regrowth or later in the season if some
    % process such as grazing has removed a critical amount of green biomass.
    A = soil_par(10);
    b = soil_par(13);
    SWP5 = mean(A*power(SWP5i*soil_par(5),b));
%     delete A b
    if mean(Ts10) > 20 && SWP5 > -1.2 && (rx*Bag - Bs)<0
        Q10 = 3;
        tr = 0.005*power(Q10,(Ta-25)/10);         % we assume that translocation is temperature dependent wth a Q10 = 3
        Tra = tr*Bs;
    else
        Tra = 0;
    end      
    %% ==================================================================================
    % respiration: maintenance respiration and growth respiration, out of period of growing
    % season, only maintenance respiration is considered
    % aboveground respiration
    ga = Veg_par(8);         % the growth respiration coefficients for aboveground compart
    ma = Veg_par(9);         % the maintenance respiration coefficients for aboveground compart  
    Q10 = 2;
    if Date <= Grd && Date >= Grs   % during the growing season
        Rat = ma*power(Q10,(Ta-20)/10)*Bag+ga*((1-ar).*Pg+Tra);
    else
        Rat = ma*power(Q10,(Ta-20)/10)*Bag;
    end
    % belowground respiration
%     partial = 0.06;               % ratio of structural materials in roots
%     mr = 0.002*(1-partial);       % the maintenance respiration coefficients for roots
    mr = Veg_par(10);
    gr = Veg_par(11);               % the growth respiration coefficients for belowground compart
    Q10 = 2;
    if Date <= Grd && Date >= Grs   % during the growing season
        Rrt = mr*power(Q10,(Ta-20)/10)*Bs+gr*(ar.*Pg-Tra);
    else
        Rrt = mr*power(Q10,(Ta-20)/10)*Bs;
    end
    % ------------------------------------------------------------------------------
    % biomass dyanmics
    % (1): living aboveground biomass, DM m^-2
    Bag = Bag + (1 - ar) .* Pg + Tra - min(Rat + Sa, Bag + (1 - ar).* Pg + Tra);
    % (2): consisting of both root and sapwood biomass for trees and shrubs,
    %       and only represents root biomass for grasses
    Bs = Bs + ar .* Pg - min(Rrt+ Ssb +Tra, Bs + ar .* Pg);
    % (3): necomass dynamics, representing abourground biomass
    %     episionD = Veg_par(23);
    Bad = Bad + Sa - min(L,Bad+Sa);         %-episionD*Bad;     % L represents litter fall
    %%
    GPg = Pg;            % Gross photosynthesis
    ToR = Rat + Rrt;     % Total respiration
    TNPP = GPg - ToR;    % Total NPP
    %% =============================================================================
    % output biomass
    Biomassout(:,:,1) = Bag;
    Biomassout(:,:,2) = Bs;
    Biomassout(:,:,3) = Bad;
end









