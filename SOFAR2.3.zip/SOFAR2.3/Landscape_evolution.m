function [DEM] = Landscape_evolution(dem,Q,S,biomass,Index,Vt,rain)
% landscape evolution because of runoff erosion
% Here we assumed the rate of tectonic uplift close to zero in the
% relatively short period, such as 50 years.
% Saco et al.,  2007 WRR
% ***********************************************************
% input parameters
% ***********************************************************
%% 
% (1) q: the surface runoff per unit width
% (2) m1: the empiric constant
% (3) n1: the empiric constant
% (4) belta: rate of sediment transport
% (5) beltamin: the empiric constant, the minimum rate of sediment
% transport
% (6) belta_v: the empiric constant
% (7) D: the diffusion coefficient
% (8) S: slope
% (9) np: the porosity of sediment
% (10) B: biomass
% (11) Index: 1, no PVs; 0: PVs
% (12) ps: density of sediment
% (13) rain: daily precipitation, mm/day
% ***********************************************************
% timestep: daily

% initialization
belta_min = 0;
belta_v = 0.04;
% rate of sediment transport for bare soil
belta_b = 0.02;            
np = 0.2;
ps = 1200;
m1 = 0.6;
n1 = 0.8;
B = sum(biomass,3)*1000;    % unit conversion, from kg/m^2 to g/m^2
% belta = ones(size(B))*belta_min;
belta = Vt.*belta_min;
A1 = (belta_v.*B.*Vt);
A2 = (1 - belta_min/belta_b);
index = find( (A1 - A2)<0);
clear A1 A2
belta(index) = belta_b*(1-Vt(index)).*(1-belta_v*B(index).*Vt(index));
clear index
% value of diffusion erosion rate for PV and bare, respectively
% D_PV = 0.04;
D_bmin = 0.001;
D_bmax = 0.002;
%% eatimate Dpv and Db based on daily rainfall
Rmax = 52.7;               % the maximum daily rainfall
Rthreshold = 2;          % threshold for rainfall splash
if rain <= Rthreshold
    D_b = D_bmin;
elseif rain > Rthreshold && rain <= Rmax
    D_b = D_bmax*(1-(Rmax-rain)/(Rmax-Rthreshold));
else
    D_b = D_bmax;
end
% PVs
length = 2;               % Length of PV panels, m
width = 1;                % Width of PV panels, m
area = 0.3;
Spv = length*width/(area);    % intercipition coefficient is rate of PVs area and interspace area
Belta = 37.2*pi/180;     % incline angel of PV panels
rainPV = Rain_distribution(rain,Belta,Spv);
if rainPV <= Rthreshold
    D_PV = D_bmin;
elseif rainPV > Rthreshold && rainPV <= Rmax
    D_PV = (D_bmax*5.9*1/6+D_bmax*5/6)*(1-(Rmax-rainPV)/(Rmax-Rthreshold));
else
    D_PV = (D_bmax*5.9*1/6+D_bmax*5/6);
end
%%
D = ones(size(Index))*D_PV;
index = find(Index == 0);
D(index) = D_b;
clear index
%%
n = 0.05;
Cn = 1/1000;
index = find(Q<0);
Q(index) = -Q(index);
q = Cn/n*power(Q,5/3).*power(S,1/2);
%%
Qs = belta.*power(q,m1).*power(S,n1);
Qs(index) = -Qs(index);
clear index
Nodate = isreal(Qs);
Nn = find(Nodate == 0);
disp(Nn)
clear Nodate Nn
if sum(sum(Q))>0
    Qd = D.*S;
    index = find(Q == 0);
    Qd(index) = 0;
    clear index
else
    Qd = zeros(size(Index));
end
dz = -(Qs./(ps*(1-np))+Qd);
% index = find(dz>0.01);
% dz(index) = 0.01;
% clear index
% landscape evolution
DEM = dem + dz;
end

