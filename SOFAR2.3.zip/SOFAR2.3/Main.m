% SOFAR (Solar farm model), a specific and synthesized model, is developed
% to simulate ecological and hydrological processes occurred in the solar
% farm. The SOFAR is run at daily time step, and driven by daily
% preicipitation, daily minimum temperature, daily maximum temperature, and
% daily radiation.
% 
% Author: Chuandong Wu
% Date: 07/05/2021
% Last updated date: 01/05/2023

% ====================================================================
clc
clear
%% parameters
% shrub
PAR(1,:) = [0.03,...   % Sh, v/v,1
    0.042,...          % Sw, v/v,2
    0.1,...            % Ss, v/v,3
    0.3,...            % Sfc, v/v,4
    0.55,...           % n, v/v,5
    50.8,...           % Ks, saturated hydrological conductiivty, cm/h,6
    4.6,...            % m, experience coefficient,7
    2,...              % N, experience constant,8
    1.62,...           % bb,9
    0.002,...          % belta,10
    5,...              % bare soil infiltration rate,11
    10,...             % vegetation cover rate,12
    -2,...             % b, 13
    5,...              % Minimum temperature for gross photosynthesis,��,1
    25,...             % Optimum temperature for gross photosynthesis,��,2
    45,...             % Maximum temperature for gross photosynthesis,��,3
    0.09,...           % Sg,specific leaf area index for living biomass,4
    0.094,...          % Sd, specific leaf area index for dead biomass,5
    0.01,...           % da, the senescence coefficient for structure biomass,d,6
    0.00018,...        % dr, the senescence coefficient for deaded biomass,d,7
    0.18,...           % ga, growth respiration for aboveground biomass,8
    0.008,...          % ma, maintenance respiration for aboveground biomass, 9
    0.02,...           % mr,maintenance respiration for root,10
    0.08,...           % gr, growth respiration for root,11
    0.18,...           % efficiency of PV,12
    0.6,...            % Kpv = 0.73;    solar radiation interception coefficient,13
    0.1,...            %  reflection ratio of PV,14
    0.1,...            % Emin, minimum soil evaporation,15
    0.98,...           % Kc, crop conversion coefficient, 16
    22,...             % Saturation point of radiation, 17
    1.05];             % rx, shoot : root ratio,18
% grass
PAR(2,:) = [0.03,...  % Sh, v/v,1
    0.06,...          % Sw, v/v,2
    0.14,...          % Ss, v/v,3
    0.4,...           % Sfc, v/v,4
    0.55,...          % n, v/v,5
    50.8,...          % Ks, saturated hydrological conductiivty, cm/h,6
    4.6,...           % m, experience coefficient,7
    2,...             % N, experience constant,8
    1.62,...          % bb,9
    0.002,...         % belta,10
    5,...             % bare soil infiltration rate,11
    20,...            % vegetation cover rate,12
    -2,...            % b, 13
    7,...             % Minimum temperature for gross photosynthesis,��,1
    25,...            % Optimum temperature for gross photosynthesis,��,2
    43,...            % Maximum temperature for gross photosynthesis,��,3
    0.01,...          % Sg,specific leaf area index for living biomass,4
    0.012,...         % Sd, specific leaf area index for dead biomass,5
    0.02,...          % da, the senescence coefficient for structure biomass,d,6
    0.00078,...       % dr, the senescence coefficient for deaded biomass,d,7
    0.1,...           % ga, growth respiration for aboveground biomass,8
    0.04,...          % ma, maintenance respiration for aboveground biomass, 9
    0.03,...          % mr,maintenance respiration for root,10
    0.11,...          % gr, growth respiration for root,11
    0.18,...          % efficiency of PV,12
    0.6,...           % Kpv = 0.73;    solar radiation interception coefficient,13
    0.1,...           %  reflection ratio of PV,14
    0.1,...           % Emin, minimum soil evaporation,15
    0.99,...          % Kc, crop conversion coefficient, 16
    20,...            % Saturation point of radiation, 17
    0.15];            % rx, shoot : root ratio,18
%% Pre-Define
Length = 439;     % Modelling sparial scale
Depth = 10;
Width = 578;      % Modelling sparial scale
Codenum = [51709,52533,51367,52679,53612,52895,53487,54423];
%%
State = 2;        % 1: PV;    2: No PV
Month = [1 31 59 90 120 151  181 212 243 273 304 334 365];       % day of each month
Cod = [5 7 8 5 7 8 5 7 8];
for filenum = 9:9
%         for i = 7:7
    i = Cod(filenum);
    Code = Codenum(i);
    longt = longt_num(i);
    lat = lat_num(i);
    if filenum>6 && filenum <=9     % precipitation scenario
        File1 = sprintf('%s%s%s','D:\SOFAR model\SOFAR2_3.1\ClimateDATA\Result_',num2str(Code),'LP.mat');
    else
        File1 = sprintf('%s%s%s','D:\SOFAR model\SOFAR2_3.1\ClimateDATA\Result_',num2str(Code),'.mat');
    end

    if filenum <= 3
        File2 = 'E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\GeographicData\PVlocation.mat';      % Please input initial DEM
    elseif filenum>4 && filenum <=6
        File2 = 'E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\GeographicData\PVlocationUp.mat';    % Please input initial DEM
    elseif filenum>6 && filenum <=9
        File2 = 'E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\GeographicData\PVlocation.mat';      % Please input initial DEM
    end
    %=========================
    for year = 39:50
        if filenum <= 3
            File3 = sprintf('%s%s%s%s%s','E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\ClimateData\Pscenario\Ra',num2str(Code),'-',num2str(year),'.mat');       % Please input incident radiation file
        elseif filenum >=4 && filenum <=6
            File3 = sprintf('%s%s%s%s%s','E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\ClimateData\DEMscenario\Ra',num2str(Code),'-',num2str(year),'Up.mat');
        elseif filenum >6 && filenum <=9
            File3 = sprintf('%s%s%s%s%s','E:\PVproject04_WRR\PVproject04\SOFAR2.3\Farm-level\ClimateData\Pscenario\Ra',num2str(Code),'-',num2str(year),'.mat');
        end

        load(File3);
        if year == 1
            x2 = [];
            LAI2 = [];
            lg2 =[];
            B2 = [];
            %             Qs2= [];
            LAIinput2 = [];
            LAIginputnew2 = [];
            %             Qsinputnew2 = [];
            Ipvinput2 =[];
            Binputnew2 = [];
            Xinputnew2 = [];
            DEM2 = [];
            [B,NPP,x,LAI,lg,LAIinputnew,LAIginputnew,...
                Ipvinput,Binputnew,Xinputnew,DEMnew,Runoff] = VWC_solve(year,Depth,Length,Width,PAR,File1,File2,Ra_G,Ra_PV,State,...
                x2,LAI2,lg2,B2,LAIinput2,LAIginputnew2,...
                Ipvinput2,Binputnew2,Xinputnew2,DEM2);
            % Save montly soil erosion
            for mon = 1:13
                DEM_mon(:,:,mon) = DEMnew(:,:,Month(mon));
            end
            
            File = sprintf('%s%s%s%s%s%s%s%s','D:\PVproject4\',...
                'S',num2str(filenum),'\Rno',num2str(Code),'_',num2str(year),'.mat');
            save(File,'B','x','LAI','lg','LAIinputnew','LAIginputnew',...
                'Ipvinput','Binputnew','Xinputnew','DEM_mon','Runoff');
        else
            File = sprintf('%s%s%s%s%s%s%s%s','D:\PVproject4\',...
                'S',num2str(filenum),'\Rno',num2str(Code),'_',num2str(year-1),'.mat');
            load(File);

            % load radiation
            load(File3);
            x2 = x;
            LAI2 = LAI;
            lg2 =lg;
            B2 = B;
            LAIinput2 = LAIinputnew;
            LAIginputnew2 = LAIginputnew;
            Ipvinput2 = Ipvinput;
            Binputnew2 = Binputnew;
            Xinputnew2 = Xinputnew;
            DEM2 = DEM_mon(:,:,13);    
            [B,NPP,x,LAI,lg,LAIinputnew,LAIginputnew,...
                Ipvinput,Binputnew,Xinputnew,DEMnew,Runoff] = VWC_solve(year,Depth,Length,Width,PAR,File1,File2,Ra_G,Ra_PV,State,...
                x2,LAI2,lg2,B2,LAIinput2,LAIginputnew2,...
                Ipvinput2,Binputnew2,Xinputnew2,DEM2);
            % Save montly soil erosion
            for mon = 1:13
                DEM_mon(:,:,mon) = DEMnew(:,:,Month(mon));
            end
            
            file3 = sprintf('%s%s%s%s%s%s%s%s','D:\PVproject4\',...
                'S',num2str(filenum),'\Rno',num2str(Code),'_',num2str(year),'.mat');
            
            save(file3,'B','x','LAI','lg','LAIinputnew','LAIginputnew',...
                'Ipvinput','Binputnew','Xinputnew','DEM_mon','Runoff');
        end
    end
    clc
    %     end
end


