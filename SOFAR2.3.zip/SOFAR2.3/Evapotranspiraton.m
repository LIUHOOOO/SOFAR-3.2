function [Ta,Ea] = Evapotranspiraton(VWC,LAIt,Lg,Tmax,Tmin,Ra,soil_par,...
    Veg_PAR,Uz,Z,Zm,PlantType)
% calculating transpiration and soil evaporation
% -----------------------------------------------------------
% S: soil moisture
% LAI: leaf area index
% Sw: plant wilting point
% S*: threshold for plant reduced transpiration
% Sh: point
%  Input parameters: (Ra,Tmax,Tmin,Uz,VPD,LAIg,Zm,Uz,RHmean,Z,Sfc,S1):
    % this function is used to calculate the evaporation and canopy transpiration
    % throughout Penman-Monteith equation
    % -------------------------------------------------------------------------------
    % Input variables description:
    % (1) Ra: incident total solar radiation/available energy
    % (2) Tmax: daily maximum temperature
    % (3) Tmin: daily minimum temperature
    % (4) Uz: wind speed at height Z
    % (5) VPD: the vapour pressure deficit if the air at a reference height above
    %      the surface
    % (6) LAIg: the live/green leaf area index
    % (8) LAIt: total leaf area index,including dead leaves
    % (7) Zm: observation height of meteorologic virables
    % (9) Z: local elevation above sea level
    % (10) RHmean: the mean relative humidity
    % (11) Sfc: field capacity
    % (12) S: soil surface soil moisture content, v/v
    % (13) VWC: volumtric water content for the first soil layer
    % (14) PlantType: 1 means short grass, and 2 means shrubs
    % -----------------------------------------------------------------------------
    % basic parameter for short grass
    Zh = Zm;
    hc = 0.12;     % reference crop height, m
    % ========================================================
    % Canopy transpiration
    Zom = 0.123*hc;
    Zoh = 0.1*Zom;
    d = 2/3*hc;
    k = 0.41;      % Karman's constant
    rac = log((Zm - d)/Zom)*log((Zh - d)/Zoh)/(power(k,2)*Uz);
    % surface resistance, rs
    ri = 100;      % bulk stomatal resistance of the well-illuminated leaf, s/m

    rsc = ri./(0.5*LAIt);
    % psychrometric constant, gamma
    gamma = 0.000665*(101.3*power((293-0.0065*Z)/293,526));
    %----------------------------------------------------------------------------------
    % daily average temperature
    Tmean = (Tmax - Tmin)/2;
    % relative humidity
    %ea = 0.6108*exp(17.27*Tmean/(Tmean+237.3))
    es = (0.6108*exp(17.27*Tmax/(Tmax+237.3))+0.6108*exp(17.27*Tmin/(Tmin+237.3)))/2;
    %%  calculating dew point temperature and actural vapour pressure
    % parameter annotation:
    % (1) EF: dimensionless, the evaporative factor;
    % (2) Pm: month amount of precipitation, m
    % (3) Ep_pre: previous daily potential evapotranspiration, kg m-2 s-1;
    % (4) pw: the water density, kg m-3
    % (5) SSD: the day length, hour

    % New method: 
    % <Estimating air humidity from temperature and precipitation measures for
    % modelling applications>
    Tday = 0.45*(Tmax-Tmean)+Tmean;
    k99 = 0.5;    % empiric coefficient
    Tdew = Tmin - k99*(Tday-Tmin);
    ea = 0.6108*exp(17.27*Tdew/(Tdew+237.3));
    %%
    % slope of saturation vapour pressure curve
    delta = 4098*(0.6108*exp(17.27*Tmean/(Tmean+237.3)))/power(Tmean+237.3,2);
    lamda= 2.45;           % MJ/kg
    pa = 1.29;             % air density, kg/m^3
    cp = power(1.013,-3);
    CoverG = (1 - exp(-0.75*LAIt)).*Lg./LAIt;    % covea fraction of green leaves
    Trmax = CoverG.*((delta*Ra+pa*cp*(es-ea)/rac)./(delta+gamma*(1+rsc./rac)))/(lamda);
    % soil propertistic parameters
    Sh = soil_par(1);   % critical soil moisture content,v/v, where soil is very dry;
    Sw = soil_par(2);   % wilting point
    Ss = soil_par(3);
    n = soil_par(5);    % soil porosity
    Kc = Veg_PAR(16);   % crop conversion parameter
    % average soil moisture content,S
    S = VWC;
    Ta = zeros(size(S));
%% Transpiration
% part 1
        index = find(0 < S & S <= Sw/n);
        Ta(index) = 0;
        clear index
% part 2
        index = find((Sw/n) < S & S <= Ss/n);
        Ta(index) = Kc*Trmax(index).*(S(index)-Sw./n)./(Ss./n-Sw./n);
        clear index
% part 3
        index  = find(S >= Ss/n);
        Ta(index) = Kc*Trmax(index);
        clear index
    
    
    
    
    % ========================================================================================
    %% bare soil evaporation
    Zom =0.01;
    d =0;
    % aerodynamic resistance, ra
    k = 0.41;             % Karman's constant
    ras = log((Zm - d)/Zom)*log((Zh - d)/Zoh)/(power(k,2)*Uz);
    %----------------------------------------------------------------------------------
    % surface resistance, rs
    Sfc = soil_par(4);       % the field capacity, v/v
    rss = 4140*(Sfc-VWC)-805;         % for bare soil
    % ---------------------------------------------------------------------------------
    % psychrometric constant, gamma
    gamma = 0.000665*(101.3*power((293-0.0065*Z)/293,526));
    %----------------------------------------------------------------------------------
    % daily average temperature
    Tmean = (Tmax - Tmin)/2;
    % slope of saturation vapour pressure curve
    delta = 4098*(0.6108*exp(17.27*Tmean/(Tmean+237.3)))/power(Tmean+237.3,2);
    %--------------------------------------------------------------------------------------
%     lamda= 2;                  % MJ/kg
    pa = 1.29;                   % air density, kg/m^3
    cp = 1.013*power(10,-3);     % MJ kg-1 ��-1
    if PlantType == 1
        k = 0.78;               % the extinction coefficient
    elseif PlantType == 2
        k = 0.56;
    end
    Rashade = Ra.*exp(-k*LAIt);            % considering the canopy shading effect
    Vtd = (1 - exp(-0.75*LAIt)).*(1-Lg)./LAIt;     % vegetation cover rage, including dead leaves
    Emax = (1-Vtd-CoverG).*((delta*Rashade+pa*cp*(es-ea)/ras)./(delta+gamma*(1+rss/ras)))/(lamda);
    Emin = Veg_PAR(15)*(1-Vtd-CoverG);
    Ea = zeros(size(S));
%% Evaporation
% part 1
        index = find(0 < VWC & VWC <= Sh/n);
        Ea(index) = 0;
        clear index
% part 2
        index = find(Sh/n < VWC & VWC <= Sw/n);
        Ea(index) = Emin(index).*(VWC(index)-Sh/n)./(Sw/n-Sh/n);
        clear index
% part 3
        index = find(Sw/n < VWC & VWC <= Ss/n);
        Ea(index) = Emin(index)+(Emax(index)-Emin(index)).*(VWC(index)-Sw/n)./(Ss/n-Sw/n);
        clear index
% part 4
        index = find(VWC > Ss/n);
        Ea(index) = Emax(index);
        clear index
end

  







