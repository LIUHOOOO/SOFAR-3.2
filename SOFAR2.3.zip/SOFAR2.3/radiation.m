function [Ra] = radiation(longt,lat)
% This code is used to calculate daily solar radiation and
% photosyhthetically active radiation (PAR)
% ----------------------------------------------------------
% Daily soalr radiation is average of per hour available radiation in
% daytime. We assumption there are 12 hours in daytime during growing
% season.
    %% calculate solar radiation intercepted by PV panes
    % parameter
    c = 0.33;             % Atmospheric transparency coefficient
    timehour = (0:1:23)';
    dayOfYear = (1:1:365);
    % total radiation:  W/m^2
    [~,Hc] = sun_position(dayOfYear,timehour,longt,lat);
    I0 = 1353*(1+0.034*cos((2*pi)*dayOfYear/365)).*((sin(Hc)./(Hc+c)));    % vertical surface
    %% per raster is different
    Ra = sum(I0)/12;
end

    function [incidenceAngle,elevationAngle] = sun_position(dayOfYear, timeHour,longt,lat)
        %SUN_POSITION calaulate the two important angles
        % The algorithm calaulates the angle of incidence of the sun on the pv panel and solar elevation angle
        %
        
        % Make sure time vector is oriented properly
        if size(timeHour,1) == 1 && size(timeHour,2) > 1
            timeHour = timeHour';
        end
        
        % Make sure day vector is oriented properly
        if size(dayOfYear,2) == 1 && size(dayOfYear,1) > 1
            dayOfYear = dayOfYear';
        end
        
        % Account for Multiple Days
        numTime = numel(timeHour);
        % numel: a function is used to conut
        numDays = numel(dayOfYear);
        timeHour = repmat(timeHour,1,numDays);
        
        % Shift solar noon for longitude
        % longitudeLocal = 102.3297*pi/180;
        % latitude =  38.1022*pi/180;
%         longitudeLocal = longt*pi/180;
        latitude =  lat*pi/180;
        
        %parameters of PV panel
        inclineAngle =37.45*pi/180;
        azimuthAngle = 0*pi/180;
        
        % Equation of Time - East/West timeshift associated with elliptical orbit
        equationTime = 9.87*sin(2*360*(dayOfYear-81)/365*(pi/180)) - ...
            7.53*cos(360*(dayOfYear-81)/365*(pi/180)) - ...
            1.5*sin(360*(dayOfYear-81)/365*(pi/180));
        solarTimeCorrection = equationTime/60 - (4*(120-longt)/60);
        solarTime = timeHour + repmat(solarTimeCorrection,numTime,1);
        
        % Angle of Sun - Related to Solar time (0 deg - vertical sun)
        hourAngle = (180*(solarTime-12)/12);
        % the negative or positive angle value defines the am-pm or pm-am???
        
        % Sun Declination - varies from +/- 23.45 during year
        sunDeclinationAngle = bsxfun(@times, ones(24,1),(23.45*sin(360*(dayOfYear+284)/365*pi/180)));
        
        % Solar incidenceAngle Angle Calculations
        cosincidenceAngle = sin(sunDeclinationAngle*pi/180)*sin(latitude)*cos(inclineAngle)...
            -sin(sunDeclinationAngle*pi/180)*cos(latitude)*sin(inclineAngle)*cos(azimuthAngle)...
            +(cos(sunDeclinationAngle*pi/180).*cos(hourAngle*pi/180))*((cos(latitude)*cos(inclineAngle))...
            +(sin(latitude)*sin(inclineAngle)*cos(azimuthAngle)))...
            +cos(sunDeclinationAngle*pi/180).*sin(hourAngle*pi/180)*sin(inclineAngle)*sin(azimuthAngle);
        incidenceAngle = acos(cosincidenceAngle);
        % sunUp = incidenceAngle > 0;
        
        % Solar elevation angle
        sinelevationAngle = sin(latitude)*sin(sunDeclinationAngle*pi/180)+...
            cos(latitude)*cos(sunDeclinationAngle*pi/180).*cos(hourAngle*pi/180);
        elevationAngle = asin(sinelevationAngle);
        % make elevationAngle >0
        index = find(elevationAngle<0);
        elevationAngle(index) = 0;
    end

% function [PAR] = PAR(Ra)
%     a = 0.5;
%     PAR = a*Ra;
% end

