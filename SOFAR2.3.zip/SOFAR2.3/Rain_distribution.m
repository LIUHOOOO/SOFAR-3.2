function [P] = Rain_distribution(Pre,Belta,S)
% Rainfall distribution model 
% calculate amounts of rainfall intercepted by PV panels
%
% Pre: precipitation from WEGN
% Belta: the inclined angle of PV panels
% Length: the length of PV panles
% Width: the width of PV panels
% reference AVrain model
%_________________________________________________
%% Parameter
%I = 0.3;              % I is rainfall intensity
%Fcum= 1.3;            % Fcum is the fraction of liquid water in the air comprised in drops with diameters less than D.
%D = -1000*(1.3*I^0.232)*log(1-Fcum);      %  drop diameter 
D = 1.5;              % drop diameter, Uncertain parameter!!!
c = 0.5;              % c is the drog coefficient
Den_s = 1000;       % density of water,kg/m3
Den_a = 1.293;        % density of air,kg/m3
g = 9.8;              % acceleration of gravity
Vd = sqrt((4*g*D*(Den_s-Den_a)/(3*Den_a*c)));             
                      % the free-fall limit velocity of a rain drop in stagnant air, m/s
Vw = 2.9;             % wind velocity, m/s
Alpha = (Vw/Vd)*pi/180;        % angle of incidence of rainfall
% Belta = 37.45;      % Belta is incline Angle of PV panels

Theta_PV = 0;         % angle of PV with the North direction
Theta_rain = 0;       % angle of rain with the North direction
%% Amounts of intervepted rainfall
%Length = 1.95/2;      % m
%Width = 1;            % m
%S = Length*Width;     % The area of PV panels
% delta = 1;    % rainfall threshold,5mm
% Pre = Pre-delta;
aa = find(Pre<=0);
Pre(aa)=0;
P = Pre*cos(Belta-tan(Alpha)*sin(Belta)*cos(Theta_PV-Theta_rain))*S;
end
