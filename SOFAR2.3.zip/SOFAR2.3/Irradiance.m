function [IHt,Ish] = Irradiance(SSD,longt,lat,Year,Date,Veg_PAR)
    Belta = 37.2;        % incline angle of PV panel
    P = 0.8;              % transparency coefficient
    Alfa = 0.12;           % ground surface albedo
    %% solar irradiance
    I0 = SSD.*radiation(longt,lat)*3600/1000000;  
        % Unit: MJ/m2/d;
    
    %% angle
    timehour = (0:1:23)';
    dayOfYear = (1:1:365);      % number of the day in one year
    % incident angle and elevation angle
    [i,Hc] = sun_position(dayOfYear,timehour,longt,lat);
        m = 1./sin(Hc(8:20,Date));       % atmosphere 
        %% beam radiation,W/m2.d
        Ibpv = I0(Year,Date)*cos(i(8:20,Date)).*P.^m;      % PV panel,matrix
        IbH = I0(Year,Date)*sin(Hc(8:20,Date)).*P.^m;      % horizontal ground,matrix
         
        % diffuse radiation, W/m2.d
        IdH = (I0(Year,Date)*(1-P.^m)/(1-1.4*log(P)))/2;    % horizontal ground,matrix
        % Idpv = Ish*(1+cos(Belta*pi/180))/2;
        F = 1-power((IdH/I0(Year,Date)),2);             % matrix
        Idpv = IdH.*(1+cos(Belta*pi/180)).*(1+F*power(sin(Belta*pi/180/2),3)).*(1+F.*power(cos(i(8:20,Date)),3).*power(cos(Hc(8:20,Date)),3));
        % reflected irradiance incident on inclined PV
        Ir = 1/2*Alfa*(IbH+IdH).*(1+power(sin(pi/4-Hc(8:20,Date)/2),2));
        %% daily average total radiation calculation
        IHt = mean(IdH+IbH);          % total irradiance of ground,W/m2
        Ipvt = mean(Idpv+Ibpv+Ir);    % total irradiance of PV, W/m2

        %% irradiance of shade area
        var1 = Veg_PAR(12);   % efficiency of PV,   0.18
        var2 = Veg_PAR(14);    % reflection ratio of PV,   0.1
        var3 = Veg_PAR(13);   % radiation interception coefficient of PV
        u = 0.384;    % shading angle
        Ish = (Ipvt-var1*Ipvt-var2*Ipvt)*var3+mean(IdH)*u;
end

function [incidenceAngle,elevationAngle] = sun_position(dayOfYear, timeHour,longt,lat)
    %SUN_POSITION calaulate the two important angles
    % The algorithm calaulates the angle of incidence of the sun on the pv panel and solar elevation angle
    % 

    % Make sure time vector is oriented properly
    if size(timeHour,1) == 1 && size(timeHour,2) > 1
        timeHour = timeHour';
    end

    % Make sure day vector is oriented properly
    if size(dayOfYear,2) == 1 && size(dayOfYear,1) > 1
        dayOfYear = dayOfYear';
    end

    % Account for Multiple Days
    numTime = numel(timeHour);
    % numel: a function is used to conut
    numDays = numel(dayOfYear);
    timeHour = repmat(timeHour,1,numDays);

    % Shift solar noon for longitude
    % longitudeLocal = 102.3297*pi/180;
    % latitude =  38.1022*pi/180;
%     longitudeLocal = longt*pi/180;
    latitude =  lat*pi/180;

    %parameters of PV panel
    inclineAngle =37.2*pi/180;
    azimuthAngle = 0*pi/180;

    % Equation of Time - East/West timeshift associated with elliptical orbit
    equationTime = 9.87*sin(2*360*(dayOfYear-81)*(pi/180)/365) - ...
        7.53*cos(360*(dayOfYear-81)*(pi/180)/365) - ...
        1.5*sin(360*(dayOfYear-81)*(pi/180)/365);
    solarTimeCorrection = equationTime/60 - (4*(120-longt)/60);
    solarTime = timeHour + repmat(solarTimeCorrection,numTime,1);

    % Angle of Sun - Related to Solar time (0 deg - vertical sun)
    hourAngle = (180*(solarTime-12)/12);
    % the negative or positive angle value defines the am-pm or pm-am???

    % Sun Declination - varies from +/- 23.45 during year
    sunDeclinationAngle = bsxfun(@times, ones(24,1),(23.45*sin(360*(dayOfYear+284)*(pi/180)/365)));

    % Solar incidenceAngle Angle Calculations
    cosincidenceAngle = sin(sunDeclinationAngle*pi/180)*sin(latitude)*cos(inclineAngle)...
        -sin(sunDeclinationAngle*pi/180)*cos(latitude)*sin(inclineAngle)*cos(azimuthAngle)...
        +(cos(sunDeclinationAngle*pi/180).*cos(hourAngle*pi/180))*((cos(latitude)*cos(inclineAngle))...
        +(sin(latitude)*sin(inclineAngle)*cos(azimuthAngle)))...
        +cos(sunDeclinationAngle*pi/180).*sin(hourAngle*pi/180)*sin(inclineAngle)*sin(azimuthAngle);
    incidenceAngle = acos(cosincidenceAngle);
    % sunUp = incidenceAngle > 0;

    % Solar elevation angle
    sinelevationAngle = sin(latitude)*sin(sunDeclinationAngle*pi/180)+...
        cos(latitude)*cos(sunDeclinationAngle*pi/180).*cos(hourAngle*pi/180);
    elevationAngle = asin(sinelevationAngle);
    % make elevationAngle >0
    index = find(elevationAngle<0);
    elevationAngle(index) = 0;
end

